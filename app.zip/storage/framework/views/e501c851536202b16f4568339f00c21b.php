<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
            <div class="title mb-5">
                <h4>Create Category</h4>
            </div>
            <form action="<?php echo e(route('categories.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('categories.partials.item_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button class="btn btn-primary mt-3" type="submit">Save</button>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary mt-3">Cancel</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/categories/create.blade.php ENDPATH**/ ?>