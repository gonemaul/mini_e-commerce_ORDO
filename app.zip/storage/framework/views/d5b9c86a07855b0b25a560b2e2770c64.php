<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.css')); ?>">
<table id="tabel" class="display hover row-border">
    <thead>
      <tr>
        <th class="text-center" style="font-weight:600;"> Profile </th>
        <th class="text-center" style="font-weight:600;"> Name </th>
        <th class="text-center" style="font-weight:600;"> Email </th>
        <th class="text-center" style="font-weight:600;"> Role </th>
        <th class="text-center" style="font-weight:600;"> Action </th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center">
              <?php if($item->profile_image): ?>
                  <img class="rounded-circle" style="width: 50px;height:50px" src="<?php echo e(asset('storage/' . $item->profile_image)); ?>"> </td>
              <?php else: ?>
                  <img class="rounded-circle" style="width: 50px;height:50px" src="https://ui-avatars.com/api/?name=<?php echo e($item->name); ?>&color=7F9CF5&background=EBF4FF"> </td>
              <?php endif; ?>
          <td class="text-center"> <?php echo e($item->name); ?> </td>
          <td> <?php echo e($item->email); ?> </td>
          <td class="text-center">
              <?php if($item->is_admin): ?>
                  <label class="badge <?php echo e(auth()->user()->id == $item->id ? 'badge-primary' : 'badge-outline-primary'); ?>">Admin</label>
              <?php else: ?>
                  <label class="badge badge-outline-warning">User</label>
              <?php endif; ?>
          <td class="text-center"><a href="<?php echo e(route('users.detail', $item->id)); ?>" class="btn btn-outline-info" style="font-size:1rem"><i class="fa-solid fa-eye"></i>Detail</a></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/js/datatables.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('#tabel').DataTable();
    })
</script>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/users/item_tabel.blade.php ENDPATH**/ ?>