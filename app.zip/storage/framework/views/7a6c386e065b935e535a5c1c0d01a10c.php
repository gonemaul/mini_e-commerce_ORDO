<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.css')); ?>">
<table id="product_tabel" class="display hover row-border">
    <thead>
      <tr>
        <th class="text-center" style="font-weight:600;"> No </th>
        <th class="text-center" style="font-weight:600;"> Product Name </th>
        <th class="text-center" style="font-weight:600;"> Category </th>
        <th class="text-center" style="font-weight:600;"> Price </th>
        <th class="text-center" style="font-weight:600;"> Stock </th>
        <th class="text-center" style="font-weight:600;"> Action </th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center"> <?php echo e($products->firstItem() + $loop->index); ?> </td>
          <td> <?php echo e($item->name); ?> </td>
          <td class="text-center"> <?php echo e($item->category->name); ?> </td>
          <td class="text-center">Rp. <?php echo e(number_format($item->price, 0, ',', '.')); ?> </td>
          <td class="text-center"> <?php echo e($item->stock); ?> </td>
          <td class="justify-content-center d-flex">
                <a href="<?php echo e(route('products.show', $item->id)); ?>" class="btn btn-outline-primary" style="margin-right: 0.5rem;font-size:1rem"><i class="fa-solid fa-eye"></i> Detail</a>
                <a href="<?php echo e(route('products.edit', $item->id)); ?>" class="btn btn-outline-warning" style="margin-right: 0.5rem;font-size:1rem"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                <form action="<?php echo e(route('products.destroy', $item->id)); ?>" method="post">
                  <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-outline-danger" onclick="return confirm('What are you sure? ..')" style="font-size:1rem"><i class="fa-solid fa-trash"></i> Delete</button>
                </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/js/datatables.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('#product_tabel').DataTable();
    })
</script>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/products/partials/item_tabel.blade.php ENDPATH**/ ?>