<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables.css')); ?>">
<table id="tabel" class="display row-border hover">
    <thead>
        <tr>
        <th class="text-center" style="font-weight:600;"> No </th>
        <th class="text-center" style="font-weight:600;"> User </th>
        <th class="text-center" style="font-weight:600;"> Total </th>
        <th class="text-center" style="font-weight:600;"> Status </th>
        <th class="text-center" style="font-weight:600;"> Action </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                <td class="text-center"><?php echo e($item->name); ?></td>
                <td class="text-center"> Rp. <?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
                <td class="text-center">
                    <?php switch($item->status):
                        case ('Success'): ?>
                            <label class="badge badge-outline-success"><?php echo e($item->status); ?></label>
                            <?php break; ?>
                        <?php case ('Pending'): ?>
                            <label class="badge badge-outline-warning"><?php echo e($item->status); ?></label>
                            <?php break; ?>
                        <?php case ('Failed'): ?>
                            <label class="badge badge-outline-danger"><?php echo e($item->status); ?></label>
                            <?php break; ?>
                        <?php case ('Expired'): ?>
                            <label class="badge badge-outline-info"><?php echo e($item->status); ?></label>
                            <?php break; ?>
                        <?php case ('Canceled'): ?>
                            <label class="badge badge-outline-danger"><?php echo e($item->status); ?></label>
                            <?php break; ?>
                        <?php default: ?>
                            <label class="badge badge-outline-secondary"><?php echo e($item->status); ?></label>
                    <?php endswitch; ?>
                </td>
                <td class="text-center">
                    <a href="<?php echo e(route('orders.detail', $item->id)); ?>" class="btn btn-outline-info"><i class="fa-solid fa-eye"></i> Detail</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/js/datatables.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('#tabel').DataTable();
    })
</script>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/orders/item_tabel.blade.php ENDPATH**/ ?>