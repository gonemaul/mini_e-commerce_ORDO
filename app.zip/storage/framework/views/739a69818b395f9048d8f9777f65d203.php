   <!-- plugins:css -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
   <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">

   <!-- Layout styles -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
   <!-- End layout styles -->
   <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" />

   <style>
    .content-wrapper{
        height: 100vh;
        width: 100%;
    }
   </style>
<div class="content-wrapper p-5">
    <div class="card bg-danger">
        Terimakasih
        Pembayaran berhasil..
    </div>
</div>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/feedback.blade.php ENDPATH**/ ?>