<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>

<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/owl-carousel-2/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>">
<style>
    .owl-carousel.portfolio-carousel.full-width .owl-nav{
        bottom: 0;
        text-align: center;
    }
    .images{
        width: 100%;
        height: 250px;
        object-fit: cover;
    }
    .images img{
        height: 250px;
    }
</style>

    <div class="content-wrapper">
        <div class="p-5 row" style="background-color: #191c24;border-radius:0.5rem">
            <div class="col-md-6 col-xl-4 stretch-card">
                <div class="card">
                  <div class="card-body p-0">
                    <div class="owl-carousel owl-theme full-width owl-carousel-dash portfolio-carousel" id="owl-carousel-basic">
                        <?php $__empty_1 = true; $__currentLoopData = $product->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="item images">
                                <img src="<?php echo e(asset('storage/' . $img->path)); ?>" alt="">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="item images">
                                <img src="<?php echo e(asset('assets/images/no-image.png')); ?>" alt="">
                            </div>
                        <?php endif; ?>
                    </div>
                  </div>
                </div>
            </div>
            <div class="col-md-6 ml-3 pl-4">
                <h3 class="mb-2"><?php echo e($product->name); ?></h3>
                <div class="row mb-1">
                    <h4 class="col-sm-9">Rp. <?php echo e(number_format($product->price, 0, ',', '.')); ?></h4>
                </div>
                <div class="row mb-4">
                    <span class="col-sm-9"><label class="badge badge-outline-success"><?php echo e($product->category->name); ?></label></span>
                </div>
                <div class="row mb-1 d-flex px-3 text-muted">
                    <span class="mr-2" style="font-size: 15px">Tersisa <?php echo e($product->stock); ?></span>
                    |
                    <span class="ml-2" style="font-size: 15px">Terjual <?php echo e($product->terjual); ?></span>
                </div>
                <div class="row mb-4 px-3">
                    <span class="text-muted" style="font-size: 15px">Added <?php echo e($product->created_at->diffForHumans()); ?></span>
                </div>
                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-outline-warning mt-2 mr-2"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-primary mt-2">Back</a>
            </div>
            <div class="col-md-12 p-3 pt-4 pl-4">
                <h4 class="text-bold">Description</h4>
                <article><?php echo $product->description; ?></article>
            </div>
        </div>
    </div>

<script src="<?php echo e(asset('assets/vendors/owl-carousel-2/owl.carousel.min.js')); ?>"></script>
<script>
    if ($('#owl-carousel-basic').length) {
      $('#owl-carousel-basic').owlCarousel({
        loop: true,
        margin: 10,
        dots: false,
        nav: true,
        autoplay: true,
        autoplayTimeout: 4500,
        navText: ["<i class='mdi mdi-chevron-left'></i>", "<i class='mdi mdi-chevron-right'></i>"],
        responsive: {
          0: {
            items: 1
          },
          600: {
            items: 1
          },
          1000: {
            items: 1
          }
        }
      });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/products/detail.blade.php ENDPATH**/ ?>