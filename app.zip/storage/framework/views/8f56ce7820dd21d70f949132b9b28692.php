<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<ul class="notifications"></ul>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/alert.css')); ?>">
<script src="<?php echo e(asset('assets/js/alert.js')); ?>"></script>
<?php if(session()->has('success')): ?>
    <input type="hidden" id="myElement" message="<?php echo e(session('success')); ?>">
    <script>
        var element = document.getElementById('myElement');
        var message = element.getAttribute('message');
        createToast('success', message);
    </script>
<?php endif; ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <div class="content-wrapper">
        <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
            <div class="d-flex justify-content-between mb-3">
                <h3 class="my-auto">Products List</h3>
                <a class="btn btn-outline-primary btn-icon-text py-auto text-center" href="<?php echo e(Route('products.create')); ?>" style="font-size:1rem;font-weight:500"><i class="fa-solid fa-plus"></i> Add Product</a>
            </div>
            <div class="table-responsive">
                <div class="text-center" id="loading" style="width:100%;">
                    <img src="<?php echo e(asset('loading.gif')); ?>" style="height: 5rem">
                    <p class="mb-0" style="font-weight: 600">Loading</p>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            $.ajaxSetup({
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post("<?php echo e(url('products/load')); ?>",{}, function(data,status){
                    $('.table-responsive').html(data);
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/products/index.blade.php ENDPATH**/ ?>