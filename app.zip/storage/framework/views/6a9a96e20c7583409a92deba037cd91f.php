<?php $__env->startSection('content'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/js/file-upload.js')); ?>"></script>
<ul class="notifications"></ul>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/alert.css')); ?>">
<script src="<?php echo e(asset('assets/js/alert.js')); ?>"></script>
<style>
    .invalid-feedback{
        display: block
    }
</style>
<div class="content-wrapper">
    <?php if(url()->current() == Route('profile')): ?>
        <?php if(session()->has('error')): ?>
        <input type="hidden" id="myElement" message="<?php echo e(session('error')); ?>">
            <script>
                var element = document.getElementById('myElement');
                var message = element.getAttribute('message');
                createToast('error', message);
            </script>
        <?php endif; ?>
        <div class="row px-4 py-4 mb-3" style="background-color: #191c24;border-radius:0.5rem">
            <div class="col-md-6 ps-3 text-center">
                <h4 class="align-center">General Account</h4>
            </div>
            <div class="col md-6 ps-3 ">
                <form action="<?php echo e(Route('update-profile')); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <div class="form-group">
                        <div class="mb-2">
                            <span>Profile Photo</span>
                        </div>
                        <div class="profileImg" style="margin-left: 1rem">
                            <?php if($user->profile_image): ?>
                                <img class="img-preview rounded-circle" style="width: 100px;height:100px" src="<?php echo e(asset('storage/' . $user->profile_image)); ?>">
                            <?php else: ?>
                                <img class="img-preview rounded-circle" style="width: 100px;height:100px" src="https://ui-avatars.com/api/?name=<?php echo e($user->name); ?>&color=7F9CF5&background=EBF4FF">
                            <?php endif; ?>
                        </div>
                        <div class="form-group mt-4">
                            <input type="file" id="profile" name="profile_image" class="file-upload-default"  onchange="imgPreview()">
                            <div class="input-group col-xs-12">
                            <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                            <span class="input-group-append">
                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                            </span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" placeholder="Name" value="<?php echo e($user->name); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" placeholder="Email" value="<?php echo e($user->email); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="btn btn-primary" type="submit">Save</button>
                </form>
            </div>
        </div>

        <div class="row px-4 py-4 mb-3" style="background-color: #191c24;border-radius:0.5rem">
            <div class="col-md-12 ps-3 text-center" style="border-bottom: 3px solid #343434;">
                <h3 class="text-danger">Danger Zone !!!</h3>
            </div>
            <div class="col-md-12 text-center" id="btn_delete">
                <button class="btn btn-outline-danger text-center mt-3 fs-3" id="delete-account">Delete Account</button>
            </div>
            <div class="col md-12 ps-3 mt-3 d-none" id="form_delete">
                <form action="<?php echo e(Route('delete-account')); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="password">Please field your password !!</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="Password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary mr-2">Back to Dashboard</a>
                    <button class="btn btn-outline-danger" onclick="return confirm('What are you sure? ..')" type="submit">Delete</button>
                </form>
            </div>
        </div>
        <script>
            $('#delete-account').click(function() {
                $('#form_delete').removeClass('d-none')
                $('#btn_delete').addClass('d-none')
            })
        </script>
    <?php else: ?>
        <?php if(session()->has('error')): ?>
        <input type="hidden" id="myElement" message="<?php echo e(session('error')); ?>">
            <script>
                var element = document.getElementById('myElement');
                var message = element.getAttribute('message');
                createToast('error', message);
            </script>
        <?php elseif(session()->has('success')): ?>
            <input type="hidden" id="myElement" message="<?php echo e(session('success')); ?>">
            <script>
                var element = document.getElementById('myElement');
                var message = element.getAttribute('message');
                createToast('success', message);
            </script>
        <?php endif; ?>
        <div class="row mt-3 px-4 py-4" id="changePassword" style="background-color: #191c24;border-radius:0.5rem">
            <div class="col-md-6 ps-3 text-center">
                <h4 class="align-center">Change Password</h4>
            </div>
            <div class="col-md-6">
                <form action="<?php echo e(Route('update-password')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="current_password" id="current_password" placeholder="Current Password">
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="New Password" >
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password_confirmation">Confirm Password</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password" >
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="btn btn-primary" type="submit">Change</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<script>
    function imgPreview() {
        const image = document.querySelector("#profile");
        const imgPreview = document.querySelector(".img-preview");

        // imgPreview.style.display = 'block';

        const oFReader = new FileReader();
        oFReader.readAsDataURL(image.files[0]);

        oFReader.onload = function(oFREvent) {
            imgPreview.src = oFREvent.target.result;
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/profile.blade.php ENDPATH**/ ?>