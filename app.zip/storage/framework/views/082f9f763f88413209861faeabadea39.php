<?php $__env->startSection('content'); ?>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<div class="content-wrapper">
    <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
        <?php switch($order->status):
            case ('Success'): ?>
                <div class="status bg-success p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
                <?php break; ?>
            <?php case ('Pending'): ?>
                <div class="status bg-warning p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
                <?php break; ?>
            <?php case ('Failed'): ?>
                <div class="status bg-danger p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
                <?php break; ?>
            <?php case ('Expired'): ?>
                <div class="status bg-info p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
                <?php break; ?>
            <?php case ('Canceled'): ?>
                <div class="status bg-danger p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
                <?php break; ?>
            <?php default: ?>
                <div class="status bg-secondary p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
                    <span><?php echo e($order->status); ?>...</span>
                </div>
        <?php endswitch; ?>
        <div class="info p-3 mb-3 d-flex justify-content-between">
            <div class="user d-flex">
                <div class="left mr-3">
                    <img class="rounded-circle" src="https://ui-avatars.com/api/?name=<?php echo e($order->name); ?>&color=7F9CF5&background=EBF4FF"> </td>
                </div>
                <div class="right">
                    <p class="m-0">
                        <span><?php echo e($order->name); ?></span>
                    </p>
                    <p class="m-0">
                        <span><?php echo e($order->phone); ?></span> |
                        <span><?php echo e($order->email); ?></span>
                    </p>
                    <p class="m-0">
                        <span><?php echo e($order->address); ?></span>
                        <span>, <?php echo e($order->city); ?></span>
                        <span><?php echo e($order->postal_code); ?></span>
                    </p>
                </div>
            </div>
            <div class="id">
                <span class="d-block">Order ID</span>
                <span>#<?php echo e($order->order_id); ?></span>
            </div>
        </div>
        <div class="product-item ">
            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3 p-3 m-0" style="border-radius:0.5rem;border: 1px solid #8c8c8c;color: ">
                    <div class="col-md-12 d-flex justify-content-between" style="width: 100%">
                        <div class="detail-left d-flex">
                            <div class="name ml-4">
                                <h4><?php echo e($item->product_name); ?></h4>
                                <label for="" class="badge badge-outline-primary"><?php echo e($item->category_name); ?></label>
                            </div>
                        </div>
                        <div class="info-right pt-3">
                            <span class="text-muted"><?php echo e($item->quantity); ?> x</span>
                            <div class="text-end">
                                Rp. <?php echo e(number_format($item->price * $item->quantity)); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="info-bottom d-flex justify-content-between p-3 mt-4" style="border: 2px dashed #B1ADD4;border-radius:0.5rem">
            <div class="left">
                <div class="mb-2 text-muted">
                    <span class="d-block">Waktu pemesanan</span>
                    <span><?php echo e($order->created_at); ?></span>
                </div>
                <div class="text-muted">
                    <span class="d-block">Waktu pembayaran</span>
                    <span><?php echo e($order->updated_at); ?></span>
                </div>
            </div>
            <div class="right d-flex align-content-center justify-content-between col-md-4">
                <div class="title">
                    <span class="d-block">Total Product</span>
                    <span class="d-block">Ongkir</span>
                    <span class="d-block">Biaya Layanan</span>
                    <span class="d-block">Total Payment</span>
                </div>
                <div>
                    <span class="d-block">Rp.</span>
                    <span class="d-block">Rp.</span>
                    <span class="d-block">Rp.</span>
                    <span class="d-block">Rp.</span>
                </div>
                <div class="body">
                    <span class="d-block"><?php echo e(number_format($order->total, 0, ',', '.')); ?></span>
                    <span class="d-block">10.000</span>
                    <span class="d-block">1.000</span>
                    <span class="d-block"><?php echo e(number_format(($order->total + 10000 + 1000), 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>
        <a href="<?php echo e(route('orders.list')); ?>" class="ml-2 mt-4 btn btn-primary">Back</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/orders/detail.blade.php ENDPATH**/ ?>