<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
<script type="text/javascript" src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/uploader.css')); ?>">
<link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">
<style>
    trix-toolbar [data-trix-button-group="file-tools"]{
        display: none
    }
    trix-toolbar .trix-button{
        background-color: rgba(167, 167, 167, 0.695);
    }
    .form-control:focus{
        color: #dddddd;
    }
    select.form-control{
        color: #dddddd;
    }
    .form-group {
        margin-top: 1rem;
        margin-bottom: 0;
    }
    .invalid-feedback {
        display: block !important;
    }
    .imageContainer {
        display: flex;
        flex-wrap: wrap;
    }
    /* .marked-for-removal .file-details{
        opacity: 0.2;
        border: 2px solid rgb(0, 0, 0);
        background-color: rgba(0, 0, 0, 0.508);
    } */
    .marked-for-removal .remove-image{
        opacity: 0;
    }
    .imageContainer .image-box{
        position: relative;
        margin: 10px;
        width: 80px;
        height: 80px;
    }
    .image-box img{
        width: 100%;
        height: 100%;
        object-fit: cover;
        border:1px solid #9e9e9e;
    }
    .image-box .remove-image{
        position: absolute;
        top: 2px;
        right: 3px;
        background-color: transparent;
        border-radius: 3px;
        border: none;
        cursor: pointer;
    }

    .image-box .remove-image i{
        color: #fff;
        transition: .3s ease;
    }

    .image-box:hover .remove-image i{
        color: #cb0909;
        padding: 20px 18px;
        font-size: 30px
    }
</style>
<input type="hidden" name="path_image" id="path_image" value="<?php echo e(old('path_image')); ?>">
<?php if($errors->any()): ?>
    <script>
        error()
    </script>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="form-group">
        <label for="name">Product Name <span class="text-danger">*</span></label>
        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" autofocus value="<?php echo e(old('name', $product->name ?? '')); ?>">
    </div>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
      <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    <div class="form-group">
        <label for="category">Category <span class="text-danger">*</span></label>
        <select class="form-control" id="category" name="category" value="<?php echo e(old('category', $product->category ?? '')); ?>">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php echo e((old('category_id', $product->category_id ?? '') == $category->id) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>


    <div class="form-group">
        <label for="price">Price <span class="text-danger">*</span></label>
        <input type="text" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="price" name="price" value="<?php echo e(old('price', $product->price ?? '')); ?>">
    </div>
    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
      <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    <div class="form-group">
        <label for="stock">Stock <span class="text-danger">*</span></label>
        <input type="text" class="form-control <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="stock" name="stock" value="<?php echo e(old('stock', $product->stock ?? '')); ?>">
    </div>
    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
      <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


    <div class="form-group">
        <label for="description">Description <span class="text-danger">*</span></label>
        <input id="description" type="hidden" name="description" value="<?php echo e(old('description', $product->description ?? '')); ?>" required>
        <trix-editor input="description"></trix-editor>
    </div>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
    <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


<?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
  <?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



<script>
//         var imagesToRemove = [];

//         $('.remove-image').on('click', function() {
//             var imageName = $(this).data('image');
//             var parentDiv = $(this).parent();

//             if (parentDiv.hasClass('marked-for-removal')) {
//                 parentDiv.removeClass('marked-for-removal');
//                 imagesToRemove = imagesToRemove.filter(function(img) { return img !== imageName; });
//             } else {
//                 parentDiv.addClass('marked-for-removal');
//                 imagesToRemove.push(imageName);
//             }
//             console.log(imagesToRemove);
//         });
// </script>

<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/products/partials/item_form.blade.php ENDPATH**/ ?>