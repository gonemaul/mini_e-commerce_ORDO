<style>
    .form-control:focus{
        color: #dddddd;
    }
    select.form-control{
        color: #dddddd;
    }
    .form-group {
        margin-top: 1rem;
        margin-bottom: 0;
    }
    .invalid-feedback {
        display: block !important;
    }
</style>
<div class="form-group">
    <label for="name">Category Name</label>
    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" placeholder="Category Name" required autofocus value="<?php echo e(old('category', $category->name ?? '')); ?>">
</div>
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
    <?php echo e($message); ?>

    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/categories/partials/item_form.blade.php ENDPATH**/ ?>