<?php $__env->startSection('content'); ?>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<div class="content-wrapper">
  <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th class="text-center" style="font-weight:600;"> Profile </th>
                  <th class="text-center" style="font-weight:600;"> Name </th>
                  <th class="text-center" style="font-weight:600;"> Email </th>
                  <th class="text-center" style="font-weight:600;"> Role </th>
                  <th class="text-center" style="font-weight:600;"> Action </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center">
                        <?php if($item->profile_image): ?>
                            <img src="<?php echo e(asset('storage/' . $item->profile_image)); ?>"> </td>
                        <?php else: ?>
                            <img src="https://ui-avatars.com/api/?name=<?php echo e($item->name); ?>&color=7F9CF5&background=EBF4FF"> </td>
                        <?php endif; ?>
                    <td> <?php echo e($item->name); ?> </td>
                    <td> <?php echo e($item->email); ?> </td>
                    <td class="text-center">
                        <?php if($item->is_admin): ?>
                            <label class="badge <?php echo e(auth()->user()->id == $item->id ? 'badge-primary' : 'badge-outline-primary'); ?>">Administrator</label>
                        <?php else: ?>
                            <label class="badge badge-outline-warning">User</label>
                        <?php endif; ?>
                    <td class="text-center"><a href="<?php echo e(route('users.detail', $item->id)); ?>" class="btn btn-outline-info" style="font-size:1rem"><i class="fa-solid fa-eye"></i>Detail</a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="d-flex justify-content-end mt-3">
                <?php echo e($users->links('components.pagination')); ?>

            </div>
          </div>
        </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/users/index.blade.php ENDPATH**/ ?>