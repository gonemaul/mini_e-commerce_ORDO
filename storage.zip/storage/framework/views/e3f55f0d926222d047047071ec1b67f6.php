<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © <a href="https://gonemaul.my.id">gonemaul.my.id</a> 2024</span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Free <a href="https://mec.gonemaul.my.id" target="_blank">Mini E-commerce</a> from gonemaul.my.id</span>
    </div>
  </footer>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/components/footer.blade.php ENDPATH**/ ?>