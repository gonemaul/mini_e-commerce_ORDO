<?php $__env->startSection('content'); ?>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<div class="content-wrapper">
    <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
        <div class="d-flex justify-content-between mb-3">
            <h3 class="my-auto">Orders List</h3>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
            <thead>
                <tr>
                <th class="text-center" style="font-weight:600;"> No </th>
                <th class="text-center" style="font-weight:600;"> User </th>
                <th class="text-center" style="font-weight:600;"> Total </th>
                <th class="text-center" style="font-weight:600;"> Status </th>
                <th class="text-center" style="font-weight:600;"> Action </th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td class="text-center"><?php echo e($item->user->name); ?></td>
                        <td class="text-center"> Rp. <?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
                        <td class="text-center">
                            <?php if($item->status == 'pending'): ?>
                                <label class="badge badge-outline-warning"><i class="fa-solid fa-hourglass-end mr-1"></i> Pending</label>
                            <?php elseif($item->status == 'in-progress'): ?>
                                <label class="badge badge-outline-primary"><i class="fa-solid fa-truck mr-1"></i> In Proccess</label>
                            <?php elseif($item->status == 'success'): ?>
                                <label class="badge badge-outline-success"><i class="fa-solid fa-circle-check mr-1"></i> Success</label>
                            <?php elseif($item->status == 'cancelled'): ?>
                                <label class="badge badge-outline-danger"><i class="fa-solid fa-circle-xmark mr-1"></i> Cancelled</label>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('orders.detail', $item->id)); ?>" class="btn btn-outline-info"><i class="fa-solid fa-eye"></i> Detail</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No data available.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            </table>
            <div class="d-flex justify-content-end mt-3">
                <?php echo e($orders->links('components.pagination')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/orders/index.blade.php ENDPATH**/ ?>