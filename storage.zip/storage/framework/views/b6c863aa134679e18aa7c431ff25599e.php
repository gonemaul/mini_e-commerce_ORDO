<?php $__env->startSection('content'); ?>
<style>
    form .file-extension .image_removed{
        opacity: 0.2; /* Mengurangi opasitas gambar */
        border: 2px solid rgb(0, 0, 0); /* Menambahkan garis tepi merah */
        background-color: rgba(0, 0, 0, 0.508);
    }
</style>
    <div class="content-wrapper">
        <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
            <div class="title mb-5">
                <h4>Edit Category</h4>
            </div>
            <form action="<?php echo e(route('products.update', $product->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('products.partials.item_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button type="submit" class="btn btn-primary mt-3" id="submit">Update Product</button>
                <a  href="<?php echo e(Route('products.index')); ?>" class="btn btn-secondary mt-3">Cancel</a>
            </form>
            <form action="" enctype="multipart/form-data" id="form_image">
                <div class="file-uploader">
                    <div class="uploader-header">
                      <h2 class="uploader-title">File Uploader</h2>
                      <h4 class="file-completed-status"></h4>
                    </div>
                    <ul class="file-list">
                        <?php if(isset($product) && $product->productImage->isNotEmpty()): ?>
                            <?php $__currentLoopData = $product->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="file-item">
                                    <div class="file-extension">
                                        <img src="<?php echo e(asset('storage/' . $image->image)); ?>" class="file-preview" id="image_<?php echo e($loop->index); ?>">
                                    </div>
                                    <div class="file-content-wrapper">
                                    <div class="file-content">
                                        <div class="file-details">
                                            <div class="file-info">
                                                <small class="file-size" style="color:#ffff " id="text_<?php echo e($loop->index); ?>">Current Image</small>
                                            </div>
                                        </div>
                                        <label class="remove-image" image_path='<?php echo e($image->image); ?>' id="<?php echo e($loop->index); ?>">
                                            <i class='bx bxs-trash'></i>
                                        </label>
                                    </div>
                                    <div class="file-progress-bar">
                                        <div class="file-progress"></div>
                                    </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <div class="file-upload-box">
                      <h2 class="box-title">
                        <span class="file-instruction">Drag files here or</span>
                        <span class="file-browse-button">browse</span>
                      </h2>
                      <input class="file-browse-input" name="files[]" type="file" multiple hidden>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/uploader.js')); ?>"></script>
    <script>
        var imagesToRemove = [];

        $('.remove-image').on('click', function() {
            const path = $(this).attr('image_path');
            const status = document.querySelector('#text_' +  $(this).attr('id'))
            const image = document.querySelector('#image_' + $(this).attr('id'))
            var parentDiv = $(this).parent();
            const remove = handleDeleteFiles(path);

            remove.addEventListener('readystatechange', () => {
                if(remove.readyState === XMLHttpRequest.DONE && remove.status === 200) {
                    var response = JSON.parse(remove.responseText);
                    status.innerText = response.status;
                    status.style.color = response.color;
                    image.classList.add('image_removed')
                    parentDiv.addClass('marked-for-removal');
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/products/edit.blade.php ENDPATH**/ ?>