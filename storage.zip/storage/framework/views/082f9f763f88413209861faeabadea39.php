<?php $__env->startSection('content'); ?>
<script src="https://kit.fontawesome.com/1b48e60650.js" crossorigin="anonymous"></script>
<div class="content-wrapper">
    <div class="p-4" style="background-color: #191c24;border-radius:0.5rem">
        <div class="status bg-warning p-3 mb-3 text-center" style="border-radius: 0.5rem;font-size:1rem;font-weight:600">
            <span>Status : </span>
            <span>Pending</span>
        </div>
        <div class="info p-3">
            <div class="buyyer mb-3">
                <div class="title mb-1">
                    <i class="fa-solid fa-user mr-1"></i> <?php echo e($order->user->name); ?>

                </div>
                <div class="body ml-4">
                    <span><?php echo e($order->user->email); ?></span>
                </div>
            </div>
        </div>
        <div class="product-item ">
            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-3 p-3 m-0" style="border-radius:0.5rem;border: 1px solid #8c8c8c;color: ">
                    <div class="col-md-12 d-flex justify-content-between" style="width: 100%">
                        <div class="detail-left d-flex">
                            <div class="product-image d-flex justify-content-between">
                                <?php if($item->product->productImage->isNotEmpty()): ?>
                                    <img class="rounded" style="width: 80px; height: 80px;border: 1px solid #8c8c8c;" src="<?php echo e(asset('storage/' . $item->product->productImage->first()->image)); ?>">
                                <?php else: ?>
                                    <img class="rounded" style="width: 80px; height: 80px:border: 1px solid #8c8c8c;" src="<?php echo e(asset('assets/images/no-image.png')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="name ml-4">
                                <h4><?php echo e($item->product->name); ?></h4>
                                <label for="" class="badge badge-outline-primary"><?php echo e($item->product->category->name); ?></label>
                            </div>
                        </div>
                        <div class="info-right pt-3">
                            <span class="text-muted"><?php echo e($item->quantity); ?> x</span>
                            <div class="text-end">
                                Rp. <?php echo e(number_format($item->price * $item->quantity)); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="details-payment p-3 col-md-4 ml-auto">
            <div class="total-products d-flex justify-content-between">
                <span>Total Product</span>
                <span>Rp. <?php echo e(number_format($order->total, 0, ',', '.')); ?></span>
            </div>
            <div class="delivery d-flex justify-content-between">
                <span>Ongkir</span>
                <span>Rp. 10.000</span>
            </div>
            <div class="pajak d-flex justify-content-between">
                <span>Biaya Layanan</span>
                <span>Rp. 1.000</span>
            </div>
            <div class="total-payment d-flex justify-content-between">
                <span>Total Payment</span>
                <span>Rp. <?php echo e(number_format(($order->total + 10000 + 1000), 0, ',', '.')); ?></span>
            </div>
        </div>
        <a href="<?php echo e(route('orders.list')); ?>" class="ml-2 mt-4 btn btn-secondary">Back</a>
        <a href="<?php echo e(route('orders.list')); ?>" class="ml-2 mt-4 btn btn-primary">Payment</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/orders/detail.blade.php ENDPATH**/ ?>