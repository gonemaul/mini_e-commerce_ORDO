<link rel="stylesheet" href="<?php echo e(asset('assets/css/pagination.css')); ?>">

<?php if($paginator->hasPages()): ?>
    <div class="pagination">
        <?php if($paginator->onFirstPage()): ?>
            <button class="button" id="startBtn" disabled>
                <i class="fa-solid fa-angles-left"></i>
            </button>
            <button class="button prevNext" id="prev" disabled>
                <i class="fa-solid fa-angle-left"></i>
            </button>
        <?php else: ?>
            <a href="<?php echo e($paginator->url(1)); ?>">
                <button class="button" id="startBtn">
                    <i class="fa-solid fa-angles-left"></i>
                </button>
            </a>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>">
                <button class="button prevNext" id="prev">
                    <i class="fa-solid fa-angle-left"></i>
                </button>
            </a>
        <?php endif; ?>

        <div class="links">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <a href="#" class="link active"><?php echo e($element); ?></a>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <a href="#" class="link active"><?php echo e($page); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="link"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>">
                <button class="button prevNext" id="next">
                    <i class="fa-solid fa-angle-right"></i>
                </button>
            </a>
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>">
                <button class="button" id="endBtn">
                    <i class="fa-solid fa-angles-right"></i>
                </button>
            </a>
        <?php else: ?>
            <button class="button prevNext" id="next" disabled>
                <i class="fa-solid fa-angle-right"></i>
            </button>
            <button class="button" id="endBtn" disabled>
                <i class="fa-solid fa-angles-right"></i>
            </button>
        <?php endif; ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\ngoding\laragon\magang\mini_e-commerce_ORDO\resources\views/components/pagination.blade.php ENDPATH**/ ?>